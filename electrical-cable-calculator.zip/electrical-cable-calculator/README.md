# Electrical Cable Selection & Voltage Drop Calculator

A command-line utility written in **C** to calculate AC load currents, evaluate voltage drops across single-phase and three-phase circuits, select suitable copper cables from a catalog, and log project records to CSV.

## Features
* **Current & Voltage Drop Calculations**: Computes AC load currents and percentage voltage drops for single-phase and three-phase systems.
* **Cable Catalog Matching**: Automatically filters and lists suitable cable sizes based on ampacity and maximum allowable voltage drop limits.
* **Record Management**: Save, list, and search past calculations stored in CSV format.
* **Unit Testing**: Verified using Google Test (`gtest`).

## Project Structure
```text
electrical-cable-calculator/
├── include/          # Header files (.h)
├── src/              # C source files (.c)
├── tests/            # Unit tests (Google Test)
├── .gitignore        # Git ignore rules
├── CMakeLists.txt    # CMake build configuration
└── README.md         # Project documentation
```

## Getting Started

### Quick Compile (GCC)
```bash
gcc src/*.c -Iinclude -lm -o cable_calculator
./cable_calculator
```

### Build with CMake & Run Tests
```bash
mkdir build && cd build
cmake ..
make
./cable_calculator
./test_calculations
```
