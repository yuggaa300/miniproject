#include <gtest/gtest.h>
extern "C" {
#include "calculations.h"
#include "cable.h"
}

TEST(CurrentTest, SinglePhase) {
    EXPECT_NEAR(calculate_current(2300, 230, 1.0, SINGLE_PHASE), 10.0, 1e-6);
}
TEST(CurrentTest, ThreePhase) {
    EXPECT_NEAR(calculate_current(6900, 400, 1.0, THREE_PHASE), 9.959, 0.01);
}
TEST(CurrentTest, ZeroPower) {
    EXPECT_DOUBLE_EQ(calculate_current(0, 230, 1, SINGLE_PHASE), 0);
}
TEST(CurrentTest, RejectZeroVoltage) {
    EXPECT_LT(calculate_current(1000, 0, 1, SINGLE_PHASE), 0);
}
TEST(CurrentTest, RejectInvalidPowerFactor) {
    EXPECT_LT(calculate_current(1000, 230, 1.2, SINGLE_PHASE), 0);
}
TEST(VoltageDropTest, SinglePhase) {
    EXPECT_NEAR(calculate_voltage_drop(10, 100, 10, 0, 1, SINGLE_PHASE), 20, 1e-6);
}
TEST(VoltageDropTest, ThreePhase) {
    EXPECT_NEAR(calculate_voltage_drop(10, 100, 10, 0, 1, THREE_PHASE), 17.3205, 1e-3);
}
TEST(VoltageDropTest, RejectNegativeLength) {
    EXPECT_LT(calculate_voltage_drop(10, -5, 10, 0, 1, SINGLE_PHASE), 0);
}
TEST(VoltageDropTest, Percentage) {
    EXPECT_NEAR(calculate_voltage_drop_percent(4.6, 230), 2.0, 0.01);
}
TEST(CableSelectionTest, ReturnsSuitableCable) {
    CableResult results[MAX_CABLES];
    int n = find_suitable_cables(5, 10, 230, 1, SINGLE_PHASE, 5,
                                 results, MAX_CABLES);
    EXPECT_GT(n, 0);
    EXPECT_GE(results[0].cable.ampacity_a, 5);
}
TEST(CableSelectionTest, RejectsInvalidLimit) {
    CableResult results[MAX_CABLES];
    EXPECT_LT(find_suitable_cables(5, 10, 230, 1, SINGLE_PHASE, 0,
                                   results, MAX_CABLES), 0);
}
