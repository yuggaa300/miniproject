#include <math.h>
#include "calculations.h"

double calculate_current(double power_w, double voltage_v,
                         double power_factor, PhaseType phase) {
    if (power_w < 0 || voltage_v <= 0 || power_factor <= 0 ||
        power_factor > 1 || (phase != SINGLE_PHASE && phase != THREE_PHASE))
        return -1.0;
    if (phase == SINGLE_PHASE)
        return power_w / (voltage_v * power_factor);
    return power_w / (sqrt(3.0) * voltage_v * power_factor);
}

double calculate_voltage_drop(double current_a, double length_m,
                              double resistance_ohm_per_km,
                              double reactance_ohm_per_km,
                              double power_factor, PhaseType phase) {
    if (current_a < 0 || length_m < 0 || resistance_ohm_per_km < 0 ||
        reactance_ohm_per_km < 0 || power_factor < 0 ||
        power_factor > 1 || (phase != SINGLE_PHASE && phase != THREE_PHASE))
        return -1.0;
    double sin_phi = sqrt(1.0 - power_factor * power_factor);
    double length_km = length_m / 1000.0;
    double factor = current_a * length_km *
        (resistance_ohm_per_km * power_factor +
         reactance_ohm_per_km * sin_phi);
    return (phase == SINGLE_PHASE) ? 2.0 * factor : sqrt(3.0) * factor;
}

double calculate_voltage_drop_percent(double drop_v, double supply_voltage_v) {
    if (drop_v < 0 || supply_voltage_v <= 0) return -1.0;
    return (drop_v / supply_voltage_v) * 100.0;
}
