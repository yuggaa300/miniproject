#include <stdio.h>
#include <string.h>
#include "records.h"

#define RECORD_FILE "records.csv"

int save_record(const char *consumer, double power_w, double voltage_v,
                double current_a, double length_m, double drop_percent,
                const char *cable_name) {
    FILE *fp = fopen(RECORD_FILE, "a");
    if (!fp) return 0;
    fprintf(fp, "%s,%.2f,%.2f,%.3f,%.2f,%.3f,%s\n",
            consumer, power_w, voltage_v, current_a, length_m,
            drop_percent, cable_name);
    fclose(fp);
    return 1;
}
void list_records(void) {
    FILE *fp = fopen(RECORD_FILE, "r");
    char line[256];
    if (!fp) { puts("No saved records yet."); return; }
    puts("\nConsumer,Power(W),Voltage(V),Current(A),Length(m),Drop(%),Cable");
    while (fgets(line, sizeof(line), fp)) fputs(line, stdout);
    fclose(fp);
}
void search_records(const char *search_term) {
    FILE *fp = fopen(RECORD_FILE, "r");
    char line[256];
    int found = 0;
    if (!fp) { puts("No saved records yet."); return; }
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, search_term)) { fputs(line, stdout); found = 1; }
    }
    if (!found) puts("No matching record found.");
    fclose(fp);
}
