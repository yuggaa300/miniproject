#include "cable.h"
#include <stddef.h>

/* Illustrative educational values only; replace with verified manufacturer data. */
static const Cable catalog[] = {
    {1, "Copper", 1.5, 12.10, 0.08, 14.0},
    {2, "Copper", 2.5, 7.41, 0.08, 20.0},
    {3, "Copper", 4.0, 4.61, 0.08, 26.0},
    {4, "Copper", 6.0, 3.08, 0.08, 34.0},
    {5, "Copper", 10.0, 1.83, 0.08, 46.0},
    {6, "Copper", 16.0, 1.15, 0.08, 61.0},
    {7, "Copper", 25.0, 0.727, 0.08, 80.0},
    {8, "Copper", 35.0, 0.524, 0.08, 99.0}
};

const Cable *get_cable_catalog(int *count) {
    if (count != NULL) *count = (int)(sizeof(catalog) / sizeof(catalog[0]));
    return catalog;
}

int find_suitable_cables(double current_a, double length_m, double voltage_v,
                         double power_factor, PhaseType phase,
                         double max_drop_percent,
                         CableResult results[], int capacity) {
    if (current_a < 0 || length_m < 0 || voltage_v <= 0 ||
        power_factor <= 0 || power_factor > 1 ||
        max_drop_percent <= 0 || results == NULL || capacity <= 0)
        return -1;

    int count = 0;
    int catalog_count = 0;
    const Cable *items = get_cable_catalog(&catalog_count);
    for (int i = 0; i < catalog_count && count < capacity; ++i) {
        if (items[i].ampacity_a < current_a) continue;
        double drop = calculate_voltage_drop(
            current_a, length_m, items[i].resistance_ohm_per_km,
            items[i].reactance_ohm_per_km, power_factor, phase);
        double percent = calculate_voltage_drop_percent(drop, voltage_v);
        if (drop >= 0 && percent <= max_drop_percent) {
            results[count].cable = items[i];
            results[count].voltage_drop_v = drop;
            results[count].voltage_drop_percent = percent;
            ++count;
        }
    }
    return count;
}
