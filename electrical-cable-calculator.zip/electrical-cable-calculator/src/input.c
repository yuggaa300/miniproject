#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "input.h"

double read_double(const char *prompt, double min_value, double max_value) {
    char line[128];
    double value;
    char extra;
    for (;;) {
        printf("%s", prompt);
        if (!fgets(line, sizeof(line), stdin)) return min_value;
        if (sscanf(line, " %lf %c", &value, &extra) == 1 &&
            value >= min_value && value <= max_value) return value;
        printf("Invalid input. Enter a value from %.2f to %.2f.\n",
               min_value, max_value);
    }
}
int read_int(const char *prompt, int min_value, int max_value) {
    char line[128];
    int value;
    char extra;
    for (;;) {
        printf("%s", prompt);
        if (!fgets(line, sizeof(line), stdin)) return min_value;
        if (sscanf(line, " %d %c", &value, &extra) == 1 &&
            value >= min_value && value <= max_value) return value;
        printf("Invalid input. Enter an integer from %d to %d.\n",
               min_value, max_value);
    }
}
void read_text(const char *prompt, char *buffer, int size) {
    printf("%s", prompt);
    if (!fgets(buffer, size, stdin)) { buffer[0] = '\0'; return; }
    buffer[strcspn(buffer, "\r\n")] = '\0';
}
