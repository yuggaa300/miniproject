#include <stdio.h>
#include <string.h>
#include "input.h"
#include "calculations.h"
#include "cable.h"
#include "records.h"

static void run_calculation(void) {
    char consumer[60];
    read_text("Enter consumer/project name: ", consumer, sizeof(consumer));
    int phase_choice = read_int("Phase (1 = single, 3 = three phase): ", 1, 3);
    while (phase_choice != 1 && phase_choice != 3) {
        puts("Please enter 1 or 3.");
        phase_choice = read_int("Phase (1 = single, 3 = three phase): ", 1, 3);
    }
    PhaseType phase = (PhaseType)phase_choice;
    double voltage = read_double("Supply voltage (V): ", 1, 1000000);
    double power_kw = read_double("Load power (kW): ", 0, 1000000);
    double pf = read_double("Power factor (0.01 to 1): ", 0.01, 1);
    double length = read_double("One-way cable length (m): ", 0, 100000);
    double limit = read_double("Maximum allowed voltage drop (%): ", 0.01, 20);

    double current = calculate_current(power_kw * 1000, voltage, pf, phase);
    printf("\nCalculated load current: %.3f A\n", current);

    CableResult matches[MAX_CABLES];
    int count = find_suitable_cables(current, length, voltage, pf, phase,
                                     limit, matches, MAX_CABLES);
    if (count <= 0) {
        puts("No cable in the sample catalogue meets both checks.");
        puts("Try reviewing the inputs or expanding the verified cable catalogue.");
        return;
    }

    puts("\nSuitable cable options (smallest listed size first):");
    printf("%-8s %-10s %-12s %-12s %-12s\n",
           "ID", "Area(mm2)", "Capacity(A)", "Drop(V)", "Drop(%)");
    for (int i = 0; i < count; ++i) {
        printf("%-8d %-10.2f %-12.2f %-12.3f %-12.3f\n",
               matches[i].cable.id, matches[i].cable.area_mm2,
               matches[i].cable.ampacity_a, matches[i].voltage_drop_v,
               matches[i].voltage_drop_percent);
    }

    char save;
    printf("\nSave the smallest suitable option? (y/n): ");
    if (scanf(" %c", &save) == 1 && (save == 'y' || save == 'Y')) {
        int ch; while ((ch = getchar()) != '\n' && ch != EOF) {}
        if (save_record(consumer, power_kw * 1000, voltage, current, length,
                        matches[0].voltage_drop_percent,
                        "Copper cable")) puts("Record saved.");
        else puts("Could not save record.");
    } else {
        int ch; while ((ch = getchar()) != '\n' && ch != EOF) {}
    }
}
int main(void) {
    int choice;
    do {
        puts("\n=== ELECTRICAL CABLE SELECTION & VOLTAGE DROP CALCULATOR ===");
        puts("1. Calculate and select cable");
        puts("2. View all saved records");
        puts("3. Search saved records");
        puts("4. Exit");
        choice = read_int("Enter choice: ", 1, 4);
        switch (choice) {
            case 1: run_calculation(); break;
            case 2: list_records(); break;
            case 3: {
                char term[60];
                int ch; while ((ch = getchar()) != '\n' && ch != EOF) {}
                read_text("Enter consumer/project name to search: ", term, sizeof(term));
                search_records(term);
                break;
            }
            case 4: puts("Thank you."); break;
        }
    } while (choice != 4);
    return 0;
}
