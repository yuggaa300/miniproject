#ifndef CALCULATIONS_H
#define CALCULATIONS_H
typedef enum { SINGLE_PHASE = 1, THREE_PHASE = 3 } PhaseType;
double calculate_current(double power_w, double voltage_v,
                         double power_factor, PhaseType phase);
double calculate_voltage_drop(double current_a, double length_m,
                              double resistance_ohm_per_km,
                              double reactance_ohm_per_km,
                              double power_factor, PhaseType phase);
double calculate_voltage_drop_percent(double drop_v, double supply_voltage_v);
#endif
