#ifndef INPUT_H
#define INPUT_H
#include <stdbool.h>
double read_double(const char *prompt, double min_value, double max_value);
int read_int(const char *prompt, int min_value, int max_value);
void read_text(const char *prompt, char *buffer, int size);
#endif
