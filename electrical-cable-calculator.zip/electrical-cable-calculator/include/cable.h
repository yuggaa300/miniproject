#ifndef CABLE_H
#define CABLE_H
#include "calculations.h"
#define MAX_CABLES 8
typedef struct {
    int id;
    char material[16];
    double area_mm2;
    double resistance_ohm_per_km;
    double reactance_ohm_per_km;
    double ampacity_a;
} Cable;
typedef struct {
    Cable cable;
    double voltage_drop_v;
    double voltage_drop_percent;
} CableResult;
const Cable *get_cable_catalog(int *count);
int find_suitable_cables(double current_a, double length_m, double voltage_v,
                         double power_factor, PhaseType phase,
                         double max_drop_percent,
                         CableResult results[], int capacity);
#endif
