#ifndef RECORDS_H
#define RECORDS_H
#include "calculations.h"
int save_record(const char *consumer, double power_w, double voltage_v,
                double current_a, double length_m, double drop_percent,
                const char *cable_name);
void list_records(void);
void search_records(const char *search_term);
#endif
